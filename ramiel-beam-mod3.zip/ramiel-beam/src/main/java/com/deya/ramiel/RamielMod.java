package com.deya.ramiel;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class RamielMod implements ModInitializer {
    public static final String MOD_ID = "ramiel";

    public static final EntityType<RamielEntity> RAMIEL = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(MOD_ID, "ramiel"),
            FabricEntityTypeBuilder.<RamielEntity>create(SpawnGroup.MONSTER, RamielEntity::new)
                    .dimensions(EntityDimensions.fixed(8.5f, 13f))
                    .fireImmune()
                    .trackRangeChunks(16)
                    .build());

    public static final Item RAMIEL_CANNON = Registry.register(
            Registries.ITEM,
            new Identifier(MOD_ID, "ramiel_cannon"),
            new RamielCannonItem(new FabricItemSettings().maxCount(1)));

    public static final Item RAMIEL_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            new Identifier(MOD_ID, "ramiel_spawn_egg"),
            new SpawnEggItem(RAMIEL, 0x1B3FD8, 0xBFE6FF, new FabricItemSettings()));

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(RAMIEL, RamielEntity.createAttributes());
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(RAMIEL_CANNON));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> entries.add(RAMIEL_SPAWN_EGG));
    }
}
