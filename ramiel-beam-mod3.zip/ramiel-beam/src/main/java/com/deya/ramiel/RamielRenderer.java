package com.deya.ramiel;

import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;

public class RamielRenderer extends EntityRenderer<RamielEntity> {
    private static final Identifier CRYSTAL = new Identifier("ramiel", "textures/entity/ramiel.png");
    private static final Identifier BEAM = new Identifier("ramiel", "textures/entity/ramiel_beam.png");
    private static final int FULL_BRIGHT = 0xF000F0;

    public RamielRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0f;
    }

    @Override
    public Identifier getTexture(RamielEntity entity) {
        return CRYSTAL;
    }

    @Override
    public boolean shouldRender(RamielEntity entity, Frustum frustum, double x, double y, double z) {
        return true; // el rayo es muy largo: no lo recortamos por el hitbox
    }

    @Override
    public void render(RamielEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vcp, int light) {
        float age = entity.age + tickDelta;
        int tick = entity.getAttackTick();
        float at = tick < 0 ? -1f : tick + tickDelta;

        float gap = 0.2f;
        if (at >= 0) {
            if (at <= RamielEntity.BEAM_END) {
                gap = 0.2f + (RamielEntity.MAX_GAP - 0.2f) * Math.min(at, RamielEntity.FORM_END) / RamielEntity.FORM_END;
            } else {
                float k = MathHelper.clamp((at - RamielEntity.BEAM_END) / (RamielEntity.FADE_END - RamielEntity.BEAM_END), 0f, 1f);
                gap = RamielEntity.MAX_GAP + (0.2f - RamielEntity.MAX_GAP) * k;
            }
        }
        float bob = MathHelper.sin(age * 0.1f) * 0.15f;
        float spin = age * 0.012f;
        float focusY = -(RamielEntity.MAX_GAP + RamielEntity.LOWER_H);

        // --- Cuerpo: dos mitades cristalinas ---
        matrices.push();
        matrices.translate(0, RamielEntity.CENTER_Y + bob, 0);
        VertexConsumer body = vcp.getBuffer(RenderLayer.getEntityTranslucent(CRYSTAL));
        drawHalf(matrices.peek(), body, 1f, gap, spin, RamielEntity.UPPER_R, RamielEntity.UPPER_H, light);
        drawHalf(matrices.peek(), body, -1f, gap, -spin, RamielEntity.LOWER_R, RamielEntity.LOWER_H, light);

        // --- Carga y gota ---
        if (at >= RamielEntity.FORM_END && at < RamielEntity.DROP_END) {
            VertexConsumer glow = vcp.getBuffer(RenderLayer.getBeaconBeam(BEAM, true));
            float charge = MathHelper.clamp((at - RamielEntity.FORM_END) / (RamielEntity.CHARGE_END - RamielEntity.FORM_END), 0f, 1f);
            float drop = MathHelper.clamp((at - RamielEntity.CHARGE_END) / (RamielEntity.DROP_END - RamielEntity.CHARGE_END), 0f, 1f);

            matrices.push();
            matrices.translate(0, focusY, 0);
            octa(matrices.peek(), glow, (0.3f + charge * 1.6f) * (1f - drop), age * 0.2f);
            matrices.pop();

            if (drop > 0f) {
                matrices.push();
                matrices.translate(0, focusY - 3f * drop, 0);
                octa(matrices.peek(), glow, 0.35f, 0f);
                matrices.pop();
            }
        }
        matrices.pop();

        // --- Rayo ---
        if (at >= RamielEntity.DROP_END && at < RamielEntity.BEAM_END) {
            drawBeam(entity, matrices, vcp, tickDelta, at, age);
        }
    }

    private void drawBeam(RamielEntity entity, MatrixStack matrices, VertexConsumerProvider vcp,
                          float tickDelta, float at, float age) {
        Vec3d start = new Vec3d(0, RamielEntity.BEAM_START_Y, 0);
        Vec3d tgt = entity.getTargetVec().subtract(entity.getLerpedPos(tickDelta));
        Vec3d dir = tgt.subtract(start);
        float len = (float) dir.length();
        if (len < 1.0E-3f) return;
        Vec3d n = dir.normalize();

        float life = at - RamielEntity.DROP_END;
        float grow = Math.min(1f, life / 4f);
        float fade = MathHelper.clamp((RamielEntity.BEAM_END - at) / 6f, 0f, 1f);
        float r = (2.2f + 0.35f * MathHelper.sin(at * 1.7f)) * grow * fade;
        if (r <= 0.01f) return;

        VertexConsumer vc = vcp.getBuffer(RenderLayer.getBeaconBeam(BEAM, true));

        matrices.push();
        matrices.translate(start.x, start.y, start.z);
        matrices.multiply(new Quaternionf().rotationTo(0f, 1f, 0f, (float) n.x, (float) n.y, (float) n.z));
        MatrixStack.Entry e = matrices.peek();
        float v0 = -age * 0.15f;
        float v1 = v0 + len * 0.25f;
        for (int i = 0; i < 3; i++) {
            float a = i * (float) Math.PI / 3f;
            float cx = MathHelper.cos(a) * r, cz = MathHelper.sin(a) * r;
            vert(e, vc, -cx, 0, -cz, 0f, v0, 0, 0, 1, FULL_BRIGHT, 1f);
            vert(e, vc, cx, 0, cz, 1f, v0, 0, 0, 1, FULL_BRIGHT, 1f);
            vert(e, vc, cx, len, cz, 1f, v1, 0, 0, 1, FULL_BRIGHT, 1f);
            vert(e, vc, -cx, len, -cz, 0f, v1, 0, 0, 1, FULL_BRIGHT, 1f);
        }
        matrices.pop();

        // Destello en el punto de impacto
        matrices.push();
        matrices.translate(tgt.x, tgt.y, tgt.z);
        octa(matrices.peek(), vc, 2.5f * grow * fade * (1f + 0.15f * MathHelper.sin(at * 2f)), age * 0.3f);
        matrices.pop();
    }

    // ---------- Geometría ----------

    /** Una mitad de Ramiel: tres pirámides superpuestas que dan un aspecto de cristal en racimo. */
    private static void drawHalf(MatrixStack.Entry e, VertexConsumer vc, float sign, float gap,
                                 float yaw, float radius, float height, int light) {
        float by = sign * gap;
        float quarter = (float) (Math.PI / 4);
        pyramid(e, vc, radius, by, sign * (gap + height), yaw, sign, light, 0.92f);
        pyramid(e, vc, radius * 0.78f, by, sign * (gap + height), yaw + quarter, sign, light, 0.92f);
        pyramid(e, vc, radius * 0.45f, by, sign * (gap + height * 1.3f), yaw + quarter, sign, light, 0.95f);
    }

    private static void pyramid(MatrixStack.Entry e, VertexConsumer vc, float r, float baseY, float apexY,
                                float rot, float sign, int light, float alpha) {
        float[] cx = new float[4];
        float[] cz = new float[4];
        for (int i = 0; i < 4; i++) {
            float a = rot + i * (float) (Math.PI / 2);
            cx[i] = MathHelper.cos(a) * r;
            cz[i] = MathHelper.sin(a) * r;
        }
        float dy = baseY - apexY;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) & 3;
            float nx = dy * cz[j] - cz[i] * dy;
            float ny = cz[i] * cx[j] - cx[i] * cz[j];
            float nz = cx[i] * dy - dy * cx[j];
            float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            nx /= l; ny /= l; nz /= l;
            if (ny * sign < 0) { nx = -nx; ny = -ny; nz = -nz; }
            vert(e, vc, 0, apexY, 0, 0.5f, 0f, nx, ny, nz, light, alpha);
            vert(e, vc, cx[i], baseY, cz[i], 0f, 1f, nx, ny, nz, light, alpha);
            vert(e, vc, cx[j], baseY, cz[j], 1f, 1f, nx, ny, nz, light, alpha);
            vert(e, vc, cx[j], baseY, cz[j], 1f, 1f, nx, ny, nz, light, alpha);
        }
        // Tapa plana que mira hacia el hueco central
        float ny = -sign;
        vert(e, vc, cx[0], baseY, cz[0], 0f, 0f, 0, ny, 0, light, alpha);
        vert(e, vc, cx[1], baseY, cz[1], 0f, 1f, 0, ny, 0, light, alpha);
        vert(e, vc, cx[2], baseY, cz[2], 1f, 1f, 0, ny, 0, light, alpha);
        vert(e, vc, cx[3], baseY, cz[3], 1f, 0f, 0, ny, 0, light, alpha);
    }

    /** Octaedro brillante (núcleo de carga, gota e impacto). */
    private static void octa(MatrixStack.Entry e, VertexConsumer vc, float size, float rot) {
        if (size <= 0.01f) return;
        pyramid(e, vc, size, 0f, size * 1.4f, rot, 1f, FULL_BRIGHT, 1f);
        pyramid(e, vc, size, 0f, -size * 1.4f, rot, -1f, FULL_BRIGHT, 1f);
    }

    private static void vert(MatrixStack.Entry e, VertexConsumer vc, float x, float y, float z,
                             float u, float v, float nx, float ny, float nz, int light, float alpha) {
        vc.vertex(e.getPositionMatrix(), x, y, z)
                .color(1f, 1f, 1f, alpha)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(e.getNormalMatrix(), nx, ny, nz)
                .next();
    }
}
