package com.deya.ramiel;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

/**
 * Ramiel: entidad flotante de dos mitades cristalinas.
 *  0-50    las mitades se separan
 *  50-85   la energía converge en el vértice inferior
 *  85-100  cae la gota
 *  100-150 rayo
 *  150-170 las mitades se juntan de nuevo
 */
public class RamielEntity extends MobEntity {
    public static final int FORM_END = 50;
    public static final int CHARGE_END = 85;
    public static final int DROP_END = 100;
    public static final int BEAM_END = 150;
    public static final int FADE_END = 170;

    // Geometría (compartida con el renderer)
    public static final float CENTER_Y = 6.5f;      // centro del modelo sobre la base de la entidad
    public static final float MAX_GAP = 2.7f;
    public static final float UPPER_R = 3.8f, UPPER_H = 3.4f;
    public static final float LOWER_R = 4.4f, LOWER_H = 3.6f;
    public static final float BEAM_START_Y = CENTER_Y - (MAX_GAP + LOWER_H) - 3.0f;

    private static final double BEAM_RADIUS = 4.0;
    private static final float BEAM_DAMAGE = 200.0f;

    private static final TrackedData<Integer> ATTACK_TICK =
            DataTracker.registerData(RamielEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<BlockPos> TARGET =
            DataTracker.registerData(RamielEntity.class, TrackedDataHandlerRegistry.BLOCK_POS);

    private boolean summoned = false;
    private UUID ownerUuid = null;

    public RamielEntity(EntityType<? extends RamielEntity> type, World world) {
        super(type, world);
        this.setNoGravity(true);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 400.0)
                .add(EntityAttributes.GENERIC_ARMOR, 20.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(ATTACK_TICK, -1);
        this.dataTracker.startTracking(TARGET, BlockPos.ORIGIN);
    }

    public int getAttackTick() {
        return this.dataTracker.get(ATTACK_TICK);
    }

    public Vec3d getTargetVec() {
        return Vec3d.ofCenter(this.dataTracker.get(TARGET));
    }

    public Vec3d getBeamStart() {
        return new Vec3d(getX(), getY() + BEAM_START_Y, getZ());
    }

    public void setSummoned(UUID owner) {
        this.summoned = true;
        this.ownerUuid = owner;
    }

    public void startAttack(Vec3d target) {
        this.dataTracker.set(TARGET, BlockPos.ofFloored(target));
        this.dataTracker.set(ATTACK_TICK, 0);
    }

    @Override
    public void tick() {
        super.tick();
        this.setVelocity(Vec3d.ZERO);
        if (getWorld().isClient || !(getWorld() instanceof ServerWorld sw)) {
            return;
        }

        int t = getAttackTick();
        if (t < 0) {
            if (summoned && age > 40) {
                discard();
            } else if (!summoned && age % 100 == 0) {
                PlayerEntity p = sw.getClosestPlayer(getX(), getY(), getZ(), 80, false);
                if (p != null) startAttack(p.getPos());
            }
            return;
        }

        if (t == 0) {
            sound(SoundEvents.BLOCK_BEACON_ACTIVATE, 4.0f, 0.6f);
        }
        if (t >= FORM_END && t < CHARGE_END) {
            tickCharge(sw, t);
        }
        if (t == DROP_END) {
            fire(sw);
        }
        if (t >= DROP_END && t < BEAM_END) {
            tickBeam(sw, t);
        }

        t++;
        if (t >= FADE_END) {
            this.dataTracker.set(ATTACK_TICK, -1);
            if (summoned) discard();
        } else {
            this.dataTracker.set(ATTACK_TICK, t);
        }
    }

    // ---------- Ataque ----------

    private void tickCharge(ServerWorld sw, int t) {
        Vec3d focus = new Vec3d(getX(), getY() + CENTER_Y - (MAX_GAP + LOWER_H), getZ());
        for (int i = 0; i < 6; i++) {
            Vec3d dir = new Vec3d(random.nextGaussian(), random.nextGaussian(), random.nextGaussian());
            if (dir.lengthSquared() < 1.0E-4) continue;
            Vec3d p = focus.add(dir.normalize().multiply(7.0));
            Vec3d v = focus.subtract(p).multiply(0.12);
            spawn(sw, ParticleTypes.END_ROD, p.x, p.y, p.z, 0, v.x, v.y, v.z, 1.0);
        }
        if (t % 10 == 0) {
            float progress = (t - FORM_END) / (float) (CHARGE_END - FORM_END);
            sound(SoundEvents.BLOCK_BEACON_POWER_SELECT, 3.0f, 0.5f + progress);
        }
    }

    private void fire(ServerWorld sw) {
        sound(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 6.0f, 0.5f);
        sound(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 6.0f, 0.5f);
        Vec3d target = getTargetVec();
        spawn(sw, ParticleTypes.FLASH, target.x, target.y, target.z, 1, 0, 0, 0, 0);
        if (sw.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)) {
            carveTunnel(sw);
        }
    }

    private void tickBeam(ServerWorld sw, int t) {
        Vec3d target = getTargetVec();
        spawn(sw, ParticleTypes.EXPLOSION, target.x, target.y, target.z, 6, 2.5, 1.5, 2.5, 0);
        spawn(sw, ParticleTypes.ELECTRIC_SPARK, target.x, target.y, target.z, 30, 3, 2, 3, 0.4);

        if (t % 2 == 0) {
            damageEntities(sw);
        }
        if (t % 5 == 0) {
            World.ExplosionSourceType type = sw.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)
                    ? World.ExplosionSourceType.TNT : World.ExplosionSourceType.NONE;
            sw.createExplosion(null, target.x, target.y, target.z, 7.0f, type);
        }
    }

    private void damageEntities(ServerWorld sw) {
        Vec3d start = getBeamStart();
        Vec3d target = getTargetVec();
        Box box = new Box(start, target).expand(BEAM_RADIUS);
        List<Entity> found = sw.getOtherEntities(this, box, e ->
                e instanceof LivingEntity && e.isAlive() && !(e instanceof RamielEntity)
                        && !e.getUuid().equals(ownerUuid));
        DamageSource source = sw.getDamageSources().mobAttack(this);
        for (Entity e : found) {
            Vec3d c = e.getPos().add(0, e.getHeight() / 2, 0);
            if (distToSegment(c, start, target) <= BEAM_RADIUS) {
                e.damage(source, BEAM_DAMAGE);
                e.setOnFireFor(10);
            }
        }
    }

    private void carveTunnel(ServerWorld sw) {
        Vec3d start = getBeamStart();
        Vec3d d = getTargetVec().subtract(start);
        double len = d.length();
        if (len < 1.0E-3) return;
        Vec3d u = d.normalize();
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (double s = 0; s <= len; s += 1.0) {
            Vec3d p = start.add(u.multiply(s));
            int bx = MathHelper.floor(p.x), by = MathHelper.floor(p.y), bz = MathHelper.floor(p.z);
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (dx * dx + dy * dy + dz * dz > 6) continue;
                        pos.set(bx + dx, by + dy, bz + dz);
                        if (!sw.isChunkLoaded(pos)) continue;
                        BlockState state = sw.getBlockState(pos);
                        if (state.isAir() || state.getHardness(sw, pos) < 0) continue;
                        sw.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                    }
                }
            }
        }
    }

    private static double distToSegment(Vec3d p, Vec3d a, Vec3d b) {
        Vec3d ab = b.subtract(a);
        double t = MathHelper.clamp(p.subtract(a).dotProduct(ab) / ab.lengthSquared(), 0, 1);
        return p.distanceTo(a.add(ab.multiply(t)));
    }

    private void sound(SoundEvent ev, float volume, float pitch) {
        getWorld().playSound(null, getX(), getY(), getZ(), ev, SoundCategory.HOSTILE, volume, pitch);
    }

    private <T extends ParticleEffect> void spawn(ServerWorld sw, T particle, double x, double y, double z,
                                                  int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayerEntity pl : sw.getPlayers()) {
            sw.spawnParticles(pl, particle, true, x, y, z, count, dx, dy, dz, speed);
        }
    }

    // ---------- Comportamiento de entidad ----------

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void takeKnockback(double strength, double x, double z) {
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return source.isOf(DamageTypes.IN_WALL) || source.isOf(DamageTypes.DROWN) || super.isInvulnerableTo(source);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("Summoned", summoned);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.summoned = nbt.getBoolean("Summoned");
    }
}
